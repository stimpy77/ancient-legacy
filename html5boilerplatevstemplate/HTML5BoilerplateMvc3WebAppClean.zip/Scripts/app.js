﻿
//
// your code here
//

if (window['app_init'] && typeof (window['app_init'] == 'function')) {
    window.app_init();
}
window['app_inited'] = true;
